Stages from outside the disc.

Put a stage's model file (.unk, the kind made for this game's mods) into this folder. It gets one more cell at the
end of the stage select, named after the file ("My_Map.unk" is shown as "My Map"). Up to 26 stages.

Optional: a file maps.txt here, one line per stage, "file.unk|Name In The Menu", gives other names and an order.

Added stages are not written to your save, and they are not offered in an online match (Tenkaichi Budokai Online).
